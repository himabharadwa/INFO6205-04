/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.neu.coe.info6205_04;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author himab
 */
public class MainTest {
    
    public MainTest() {
    }
    
    
    // TODO add test methods here.
    // The methods must be annotated with annotation @Test. For example:
    //
     @Test
     public void geneSequence() {
         Items a = new Items();
         a.setValue(6);
         a.setWeight(6);
         Main.items_array[0] = a;
         Items b = new Items();
         a.setValue(9);
         a.setWeight(4);
         Main.items_array[1] = b;
         Items c = new Items();
         a.setValue(8);
         a.setWeight(3);
         Main.items_array[2] = c;
         Items d = new Items();
         a.setValue(5);
         a.setWeight(3);
         Main.items_array[3] = d;
         Items e = new Items();
         a.setValue(8);
         a.setWeight(5);
         Main.items_array[4] = e;
//        
        Solution sa = new Solution();
        sa.getGene().add(1);
        sa.getGene().add(0);
        sa.getGene().add(0);
        sa.getGene().add(1);
        sa.getGene().add(1);
        
        Main.nGenSolution.add(sa);
        
        Solution sb = new Solution();
        sb.getGene().add(0);
        sb.getGene().add(0);
        sb.getGene().add(0);
        sb.getGene().add(1);
        sb.getGene().add(1);
        
        Solution sc = new Solution();
        sb.getGene().add(0);
        sb.getGene().add(0);
        sb.getGene().add(1);
        sb.getGene().add(1);
        sb.getGene().add(1);
        
        Solution sd = new Solution();
        sb.getGene().add(0);
        sb.getGene().add(1);
        sb.getGene().add(0);
        sb.getGene().add(1);
        sb.getGene().add(1);
        
        Solution se = new Solution();
        sb.getGene().add(0);
        sb.getGene().add(1);
        sb.getGene().add(1);
        sb.getGene().add(1);
        sb.getGene().add(1);
        
        Solution sf = new Solution();
        sb.getGene().add(1);
        sb.getGene().add(1);
        sb.getGene().add(1);
        sb.getGene().add(1);
        sb.getGene().add(0);
        
        Solution sg = new Solution();
        sb.getGene().add(1);
        sb.getGene().add(1);
        sb.getGene().add(1);
        sb.getGene().add(1);
        sb.getGene().add(1);
        
        
        Main.nGenSolution.add(sb);
       int g1=  Main.nGenSolution.get(0).getGene().get(0).intValue();
         assertEquals(1,g1);
         int g2=  Main.nGenSolution.get(0).getGene().get(1);
         assertEquals(0,g2);
         int g3=  Main.nGenSolution.get(0).getGene().get(2);
         assertEquals(0,g3);
         int g4=  Main.nGenSolution.get(0).getGene().get(3);
         assertEquals(1,g4);
         int g5=  Main.nGenSolution.get(0).getGene().get(4);
         assertEquals(1,g5);
         
//  
//        
        
//       
//     
      
//        

        

     }
     
     @Test
     public void fitnessCalculation(){
    Main.evaluatePopulation();
     Solution sol = Main.bestSolution();
     sol.fitnessCalculator();;
     double fitness = sol.getFitness();
     
        assertEquals(8.0, fitness,0);

       
}
     
     @Test
     public void solution(){
         Main.evaluatePopulation();
         if(Main.generation>1){
             Main.createnewGeneration();
         }
         if(Main.generation>79 && Main.generation<85)
         assertTrue(true);
     }
}
