/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.neu.coe.info6205_04;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Random;

/**
 *
 * @author ankitbhikadia
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static int generation = 100;
    public static final int totalItems = 5;
    public static final int capacity = 30;
    public static final int populationCount = 100;
    public static int currentGeneration = 0;
    public static double crossoverChances = 0.6;
    public static double cullingv = 0.90; 
    public static double mutationChances = 0.05;
    public static Items[] items_array = new Items[totalItems];
    public static ArrayList<Population> totPopulation = new ArrayList<Population>();
    public static ArrayList<Solution> nGenSolution = new ArrayList<Solution>();
    public static ArrayList<Solution> breedPopulation = new ArrayList<Solution>(); 
    public static Population currPopulation; 
   

    
    public static int populationFitness() {
        int temp = 0;
        for (int i = 0; i < nGenSolution.size(); i++) {
            if(capacity<=nGenSolution.get(i).getWeight()){
                temp = (int) (temp + nGenSolution.get(i).getFitness());
            }
            
        }
        return temp;
    }

    public static Solution bestSolution() {
       int index = 0;
        double currentFittness = 0;
        double best = 0;
        for (int i = 0; i < nGenSolution.size(); i++) {
            currentFittness = nGenSolution.get(i).getFitness();
            if (best<currentFittness) {
                best = currentFittness;
                index = i;
            }
            
        } return nGenSolution.get(index);
    }

    private static double newmeanPopulation() {
       double mean = 0;
       double total = 0;
       for (int i = 0; i < nGenSolution.size(); i++) {
            total = total + nGenSolution.get(i).getFitness();
            
            }
       mean = total/populationCount;
           return mean; 
        }
    

    public static void evaluatePopulation() {
      currPopulation = new Population();
      currPopulation.setFitnessTotal(populationFitness());
      currPopulation.setSolution(bestSolution());
        currPopulation.setMeanfitness(newmeanPopulation());
        totPopulation.add(currPopulation);  
    }

    private static int randGene() {
        
        double number = Math.random()*currPopulation.getFitnessTotal();
       for(int i = 0; i < populationCount; i++) {
            if(number <= nGenSolution.get(i).getFitness()) {
                return i;
            }
            number = number - nGenSolution.get(i).getFitness();
        }
        return 0;
    }

    private static void crossover(int gene1, int gene2) {
       ArrayList<Integer> child1 = new ArrayList<>();
        ArrayList<Integer> child2 = new ArrayList<>();
   double rand = Math.random();
        if(rand<=crossoverChances)
        {
            Random generator = new Random();
            int divide = generator.nextInt(totalItems) + 1;
          //  int divide = totalItems/2;
            child1.addAll(nGenSolution.get(gene1).getGene().subList(0, divide));
            child1.addAll(nGenSolution.get(gene2).getGene().subList(divide, nGenSolution.get(gene2).getGene().size()));
            
            
            child2.addAll(nGenSolution.get(gene2).getGene().subList(0, divide));
            child2.addAll(nGenSolution.get(gene1).getGene().subList(divide, nGenSolution.get(gene2).getGene().size()));
            
            
            breedPopulation.add(new Solution(child1));
            breedPopulation.add(new Solution(child2));
        }
        else {
            breedPopulation.add(nGenSolution.get(gene1));
            breedPopulation.add(nGenSolution.get(gene2));
        }
    }   

    private static void mutuation() {
        double randMu = Math.random();
        if(randMu >= mutationChances){
            System.out.println("Mutation involved...");
            int mutationIndex = (int)(Math.random() * totalItems);  
            int mutationSolution = (int)(Math.random() * breedPopulation.size()); 
            
            if(breedPopulation.get(mutationSolution).getGene().get(mutationIndex) == 1)
                breedPopulation.get(mutationSolution).getGene().set(mutationIndex, 0);
            else
               breedPopulation.get(mutationSolution).getGene().set(mutationIndex, 1);
           }
    }

    public static void createnewGeneration() {
    for(int i=1;i<generation;i++)
    {
                breedPopulation = new ArrayList<>();
                
                if((generation>=3) && (i>generation *0.8)) {
                    double a = totPopulation.get(i-1).getSolution().getFitness();
                    double b = totPopulation.get(i-2).getSolution().getFitness();
                    double c = totPopulation.get(i-3).getSolution().getFitness();
                    if(a == b && b == c){
                        System.out.println("Stop condition meet at gen " + (i-1));
                        System.out.print("Total Value Possible - "+ (totPopulation.get(i-1).getSolution().getFitness()) + " With inclusion of items -:");
                       for(int x:totPopulation.get(i-1).getSolution().getGene())
                           System.out.print(x);
                       System.out.println("");
                        generation = i;
                        break;
                    }
                }
                System.out.println("Generation" + i);
                //Breed new gen
                for(int br = 0; br< generation/2;br++){
                    int gene1;
                    int gene2;
                    currentGeneration = currentGeneration+1;
                    if(populationCount%2 == 1){
                        breedPopulation.add(totPopulation.get(currentGeneration-1).getSolution());
                    }
                    gene1 = randGene();
                    gene2 = randGene();
                    
                    crossover(gene1,gene2);
                   
                    
                    
                   
                         
            }
                mutuation();
                 //fitness of the new breed
                    for (int q = 0; q < breedPopulation.size(); q++) {
                     breedPopulation.get(q).fitnessCalculator();
                    }
                     //copying to population
//                    System.out.print(breedPopulation.size()+ " "+  populationCount+ " "+ nGenSolution.size());
                     for(int k = 0; k < breedPopulation.size(); k++) {
//                         System.out.println(nGenSolution.size());
                         nGenSolution.add(k,breedPopulation.get(k));
                     
                     
//                     System.out.print(nGenSolution.get(k));
        }
                     // new op
                     System.out.println("Gen Pool        Fitness");
                     System.out.println("---------------------------------------");
            for (int p = 0; p < nGenSolution.size(); p++) {
                for (int z : nGenSolution.get(p).getGene()) {
                    System.out.print(z);
                }
                
                System.out.println("   " + nGenSolution.get(p).getFitness());
            }
            
                
            nGenSolution = culling(nGenSolution);
            currPopulation = new Population();
            currPopulation.setFitnessTotal(populationFitness());
            currPopulation.setSolution(bestSolution());
            currPopulation.setMeanfitness(newmeanPopulation());
            totPopulation.add(currPopulation); 
            }    
    }
    public double totalfitnessGen = 0;
    public static Population populationNow;
    
    private ArrayList<Double> newGeneration = new ArrayList<Double>();
    
    
    
    public static void main(String[] args) {
        try {
                File file_name = new File("Output");
                if(file_name.exists()) {
                    file_name.delete();
                }
                FileOutputStream fos = new FileOutputStream(file_name, true);
                PrintStream ps = new PrintStream(fos);
                System.setOut(ps);
            }
            catch(FileNotFoundException e) {
                System.out.println("Problem with output file");
            }
        
        randomgeneratedItems();   
        System.out.println("Items And values with Weights.....");
        for(int i =0;i<totalItems;i++)
        {
            System.out.print(  items_array[i].getValue() + "  ");
            
        }
        System.out.println();
        for(int i =0;i<totalItems;i++)
        {
            System.out.print(  items_array[i].getWeight()+ "  ");
            
        }
        
        System.out.println();
        
        randomgeneratedPopulation();
        System.out.println("generation  0..");
        for (int i=0;i<populationCount;i++){
            System.out.println("   " + nGenSolution.get(i).getValue()+ "  "+ nGenSolution.get(i).getWeight()) ;
            for (int z : nGenSolution.get(i).getGene()) {
                System.out.print(z);
            }
        }
        System.out.println();
        
        evaluatePopulation();
        
        if(generation>1){
            System.out.println(" Generation.....in making");
            createnewGeneration();
            
        }
     

        
        
        
        
    }
        public static ArrayList<Solution> culling(ArrayList<Solution> toBeCulled) {

        double check = Math.random();
        if (check > 0.5) {     
           Collections.sort(toBeCulled);
            
            int cutoff = (int) (cullingv * toBeCulled.size());
            ArrayList<Solution> pop = new ArrayList<>();
            for (int i = 0; i <= cutoff; i++) {
                pop.add(toBeCulled.get(i));
            }

            for (int j = 0; j < pop.size(); j++) {
                for (int z : pop.get(j).getGene()) {
                    System.out.print(z);
                }
                System.out.println("        " + pop.get(j).getFitness());
            }

            return pop;
        } else {       
            return toBeCulled;
        }
    }
    
    private static void randomgeneratedItems(){
        Random r = new Random();
        for(int i =0; i< totalItems; i++){
            Items item = new Items();
            item.setValue(r.nextInt(10));
            item.setWeight(r.nextInt(10));
            items_array[i] = item;
        }
        
    }

    private static void randomgeneratedPopulation() {
        
        for (int i =0;i<populationCount;i++){
            Solution s = new Solution();
            s.generateGene();
            nGenSolution.add(s);
            
        }
    }

    
    
    
}
