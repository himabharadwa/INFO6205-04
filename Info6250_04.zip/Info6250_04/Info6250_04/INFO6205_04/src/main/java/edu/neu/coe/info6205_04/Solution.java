/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.neu.coe.info6205_04;

import java.util.ArrayList;
import java.util.Random;

/**
 *
 * @author himab
 */
public class Solution implements Comparable{
    private ArrayList<Integer> gene = new ArrayList<>();
    private double weight = 0.0;
    private double value = 0.0;
    private double fitness = 0.0;

    public Solution(){
        
    }
    
    public Solution(ArrayList<Integer> seq){
        this.gene = seq;
    }
    public ArrayList<Integer> getGene() {
        return gene;
    }

    public void setGene(ArrayList<Integer> gene) {
        this.gene = gene;
    }


    public double getWeight() {
        return weight;
    }

    public void setWeight(double weight) {
        this.weight = weight;
    }

    public double getValue() {
        return value;
    }

    public void setValue(double value) {
        this.value = value;
    }

    public double getFitness() {
        return fitness;
    }

    public void setFitness(double fitness) {
        this.fitness = fitness;
    }
    
    
    public void generateGene(){
        Random rand = new Random();
        for(int i=0; i< Main.totalItems; i++){
                this.gene.add(rand.nextInt(2));
        }
        
        this.fitnessCalculator();
    }
    
    public void fitnessCalculator(){
        double tempWeight=0.0, tempValue=0.0;
        for(int i=0; i< Main.totalItems; i++){
            if(this.gene.get(i) == 1){
                tempValue = tempValue + Main.items_array[i].getValue();
                tempWeight = tempWeight + Main.items_array[i].getWeight();
            }
        }
        this.weight = tempWeight;
        this.value = tempValue;
        if(this.weight <= Main.capacity)
            this.fitness = this.value;
    }   
    
     @Override
    public int compareTo(Object comparestu) {
        double compareFitness=((Solution)comparestu).getFitness();
        /* For sorting in descending order do like this */
        return (int)(compareFitness-this.fitness);
    }
}
